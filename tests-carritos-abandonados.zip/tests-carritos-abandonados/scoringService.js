// Extraído literalmente del nodo "Scoring - Clasificar Lead1"
// (n8n-nodes-base.code) del workflow "Sinergia Digital - Recuperación
// de Carritos v4". Se separa aquí SOLO para poder testear la lógica
// con Jest fuera del entorno de n8n; el código de negocio es idéntico
// al que corre en producción.

const CART_VALUE_MAX = 200000; // ARS — precio máx. catálogo × 1,1
const ABANDONMENT_MAX = 5;     // umbral de abandono recurrente

const W_VALUE = 0.50;
const W_ABANDONMENT = 0.30;
const W_STAGE = 0.20;

const STAGE_SCORES = {
  browsing: 0.25,
  cart: 0.50,
  checkout_started: 0.75,
  payment_page: 1.00,
};

function calcularScoring({ cart_value, previous_abandonment_count, cart_stage }) {
  const cartValue = parseFloat(cart_value) || 0;
  const abandonmentCount = parseInt(previous_abandonment_count) || 0;
  const stage = cart_stage || 'cart';

  const pValor = Math.min(cartValue / CART_VALUE_MAX, 1);
  const pAbandono = Math.min(abandonmentCount / ABANDONMENT_MAX, 1);
  const pEtapa = STAGE_SCORES[stage] ?? 0.25;

  const puntuacion = (pValor * W_VALUE + pAbandono * W_ABANDONMENT + pEtapa * W_STAGE) * 100;

  let prioridad;
  if (puntuacion >= 70) {
    prioridad = 'ALTA';
  } else if (puntuacion >= 40) {
    prioridad = 'MEDIA';
  } else {
    prioridad = 'BAJA';
  }

  return { puntuacion: Math.round(puntuacion * 10) / 10, prioridad };
}

module.exports = { calcularScoring, CART_VALUE_MAX, ABANDONMENT_MAX, STAGE_SCORES };
