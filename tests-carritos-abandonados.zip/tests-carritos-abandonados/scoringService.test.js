const { calcularScoring } = require('./scoringService');

describe('calcularScoring — caso de referencia del Anexo A', () => {
  test('carrito de $265.000, checkout_started, 2 abandonos previos → 77.0 / ALTA', () => {
    const resultado = calcularScoring({
      cart_value: 265000,
      cart_stage: 'checkout_started',
      previous_abandonment_count: 2,
    });
    expect(resultado.puntuacion).toBeCloseTo(77.0, 1);
    expect(resultado.prioridad).toBe('ALTA');
  });
});

describe('calcularScoring — sesiones reales de U02 (Anexo E, filas 2-9)', () => {
  // Cada caso replica exactamente una fila real de la Tabla E1 del Anexo E
  // (usuario U02, cart_value $75.000, distintas etapas y abandonos previos).
  test.each([
    { fila: 2, cart_stage: 'cart', previous_abandonment_count: 0, esperado: 'BAJA' },
    { fila: 4, cart_stage: 'cart', previous_abandonment_count: 1, esperado: 'BAJA' },
    { fila: 5, cart_stage: 'checkout_started', previous_abandonment_count: 2, esperado: 'MEDIA' },
    { fila: 6, cart_stage: 'cart', previous_abandonment_count: 3, esperado: 'MEDIA' },
    { fila: 7, cart_stage: 'cart', previous_abandonment_count: 4, esperado: 'MEDIA' },
    { fila: 8, cart_stage: 'cart', previous_abandonment_count: 5, esperado: 'MEDIA' },
    { fila: 9, cart_stage: 'checkout_started', previous_abandonment_count: 6, esperado: 'MEDIA' },
  ])('fila $fila del Anexo E ($cart_stage, $previous_abandonment_count abandonos) → $esperado', ({ cart_stage, previous_abandonment_count, esperado }) => {
    const resultado = calcularScoring({ cart_value: 75000, cart_stage, previous_abandonment_count });
    expect(resultado.prioridad).toBe(esperado);
  });
});

describe('calcularScoring — casos límite', () => {
  test('carrito en $0 sin abandonos, etapa browsing → BAJA con puntuación mínima', () => {
    const resultado = calcularScoring({ cart_value: 0, cart_stage: 'browsing', previous_abandonment_count: 0 });
    expect(resultado.puntuacion).toBeCloseTo(5.0, 1); // solo aporta P_etapa: 0.25*20
    expect(resultado.prioridad).toBe('BAJA');
  });

  test('carrito muy por encima del máximo del catálogo se capea en 1 (no supera el 100%)', () => {
    const resultado = calcularScoring({ cart_value: 1000000, cart_stage: 'payment_page', previous_abandonment_count: 5 });
    // pValor y pAbandono quedan ambos en 1 por el Math.min, no siguen creciendo
    expect(resultado.puntuacion).toBeCloseTo(100.0, 1);
    expect(resultado.prioridad).toBe('ALTA');
  });

  test('previous_abandonment_count por encima del umbral (5) no sigue sumando puntos', () => {
    const conCinco = calcularScoring({ cart_value: 75000, cart_stage: 'cart', previous_abandonment_count: 5 });
    const conCien = calcularScoring({ cart_value: 75000, cart_stage: 'cart', previous_abandonment_count: 100 });
    expect(conCien.puntuacion).toBeCloseTo(conCinco.puntuacion, 5);
  });

  test('cart_stage desconocido o ausente cae al valor por defecto de "browsing" (0.25)', () => {
    const conEtapaInvalida = calcularScoring({ cart_value: 75000, cart_stage: 'etapa_inexistente', previous_abandonment_count: 0 });
    const conBrowsingExplicito = calcularScoring({ cart_value: 75000, cart_stage: 'browsing', previous_abandonment_count: 0 });
    expect(conEtapaInvalida.puntuacion).toBeCloseTo(conBrowsingExplicito.puntuacion, 5);
  });

  test('los tres umbrales de clasificación son mutuamente excluyentes y correctos', () => {
    expect(calcularScoring({ cart_value: 200000, cart_stage: 'payment_page', previous_abandonment_count: 5 }).prioridad).toBe('ALTA'); // 100
    expect(calcularScoring({ cart_value: 200000, cart_stage: 'browsing', previous_abandonment_count: 0 }).prioridad).toBe('MEDIA'); // 55
    expect(calcularScoring({ cart_value: 0, cart_stage: 'browsing', previous_abandonment_count: 0 }).prioridad).toBe('BAJA'); // 5
  });
});
