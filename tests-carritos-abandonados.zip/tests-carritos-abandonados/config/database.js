// Stub — reemplazado por jest.mock() en los tests
module.exports = { query: () => {} };
